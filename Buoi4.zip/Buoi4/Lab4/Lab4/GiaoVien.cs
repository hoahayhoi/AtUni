﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
   public class GiaoVien
    {
        string tenGV;
        int soNHD;

        public int SoNHD
        {
            get { return soNHD; }
            set { soNHD = value; }
        }
        public string TenGV
        {
            get { return tenGV; }
            set { tenGV = value; }
        }
        

        public GiaoVien() { }

        public GiaoVien(string ptenGV, int psoNHD) 
        {
            this.tenGV = ptenGV;
            this.soNHD = psoNHD;
        }

        public void Nhap()
        {
            Console.WriteLine("Nhap vao ten GV: ");
            this.tenGV = Console.ReadLine();
            Console.WriteLine("Nhap vao so nhom huong dan(>=0): ");
            this.soNHD = int.Parse(Console.ReadLine());
        }

        public void Xuat()
        {
            Console.WriteLine("Ten GV: {0}\n So nhom huong dan: {1}", this.tenGV, this.soNHD);
        }


    }
}
