﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab4
{
    public class ThiSinh
    {
        int sbd;
        string ten, namsinh;
        double diemtoan, diemvan, diemngoaingu;

        public string Ten
        {
            get { return ten; }
            set { ten = value; }
        }
        

        public int Sbd
        {
            get { return sbd; }
            set { sbd = value; }
        }


        public string Namsinh
        {
            get { return namsinh; }
            set { namsinh = value; }
        }

        public double Diemtoan
        {
            get { return diemtoan; }
            set { diemtoan = value; }
        }

        public double Diemvan
        {
            get { return diemvan; }
            set { diemvan = value; }
        }

        public double Diemngoaingu
        {
            get { return diemngoaingu; }
            set { diemngoaingu = value; }
        }

        public ThiSinh(int psbd, string pten, string pnamsinh, double pdtoan, double pdvan, double pdngoaingu)
        {
            this.sbd = psbd;
            this.ten = pten;
            this.namsinh = pnamsinh;
            this.diemtoan = pdtoan;
            this.diemvan = pdvan;
            this.diemngoaingu = pdngoaingu;
        }
        public ThiSinh()
        {

        }
        public ThiSinh(ThiSinh a)
        {
            this.sbd = a.sbd;
            this.ten = a.ten;
            this.namsinh = a.namsinh;
            this.diemtoan = a.diemtoan;
            this.diemvan = a.diemngoaingu;
        }

        public double TongDiem()
        {
            return (Diemngoaingu * 2) + Diemtoan + Diemvan;
        }

        public string KetQua()
        {
            double xet = TongDiem();
            if (xet > 25) return "Dau";
            else return "Rot";
        }


        public void Xuat()
        {
            Console.WriteLine("Thi Sinh: ----------------------------------------------");
            Console.WriteLine("SBD: {0}\nHoTen: {1}\nNam Sinh: {2}\nDiem Toan: {3} Diem van: {4} Diem Anh: {5}\nTong Diem: {6} Ket Qua: {7}"
                , sbd, ten, namsinh, diemtoan, diemvan, diemngoaingu, TongDiem(), KetQua());
        }





    }
}
