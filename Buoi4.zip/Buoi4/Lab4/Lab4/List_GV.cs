﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Lab4
{
   public class List_GV
    {
        public List<GiaoVien> list_GV = new List<GiaoVien>();

        public void Nhap(int n)
        {
            for (int i = 0; i < n; i++)
            {
                GiaoVien x = new GiaoVien();

                x.Nhap();
            }
        }

        public void Nhap(string filePath)
        {
            XmlDocument read = new XmlDocument();
            read.Load(filePath);
            XmlNodeList nodeList = read.SelectNodes("/DanhSach/GV");
            foreach(XmlNode node in nodeList)
            {
                GiaoVien a = new GiaoVien();
                a.TenGV = node["HoTen"].InnerText;
                a.SoNHD = int.Parse(node["SoNhom"].InnerText);
                list_GV.Add(a);
            }
        }

        public void Xuat()
        {
            foreach (GiaoVien x in list_GV)
            {
                x.Xuat();
            }
        }

        public int TongNhom()
        {
            return list_GV.Sum(t => t.SoNHD);
        }

        public List<GiaoVien> SX_TheoHo()
       {
           return list_GV.OrderBy(t => t.TenGV).ToList<GiaoVien>();
       }

       public List<GiaoVien> SX_GiamTheoNhom()
       {
           return list_GV.OrderByDescending(t => t.SoNHD).ToList<GiaoVien>();
       }

       public List<GiaoVien> DS_Nhom_LonHon1()
       {
           List<GiaoVien> t = new List<GiaoVien>();
           foreach (GiaoVien x in list_GV)
           {
               if (x.SoNHD > 1) t.Add(x);
           }
           return t;
       }

    }
}
