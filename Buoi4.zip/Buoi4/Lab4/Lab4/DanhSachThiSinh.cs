﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace Lab4
{
    class DanhSachThiSinh
    {
        public List<ThiSinh> ds_ThiSinh = new List<ThiSinh>();

        public void Nhap(string filePath)
        {
            XmlDocument read = new XmlDocument();
            read.Load(filePath);
            XmlNodeList nodeList = read.SelectNodes("");

            foreach (XmlNode node in nodeList)
            {
                ThiSinh a = new ThiSinh();
                a.Sbd = node[SBD].InnerText;
                a.Ten = node[Ten].InnerText;


            }


        }
    }
}
