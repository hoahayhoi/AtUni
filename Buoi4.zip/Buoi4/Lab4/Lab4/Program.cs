﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            List_GV dsGV = new List_GV();

            dsGV.Nhap(@"C:\Users\Administrator\Desktop\Buoi4\Lab4\Lab4\GV.xml");

            dsGV.Xuat();

            int tongsonhom = dsGV.TongNhom();
            Console.WriteLine("tong so nhom huong dan la: {0}", tongsonhom);

            Console.WriteLine("sx giam dan theo nhom-------------------------------------------------------------");
            List_GV t1 = new List_GV();
            t1.list_GV = dsGV.SX_GiamTheoNhom();
            t1.Xuat();

            Console.WriteLine("sx tang dan theo ten-------------------------------------------------------------");
            List_GV t2 = new List_GV();
            t2.list_GV = dsGV.SX_TheoHo();
            t2.Xuat();


            Console.ReadKey();
        }
    }
}
