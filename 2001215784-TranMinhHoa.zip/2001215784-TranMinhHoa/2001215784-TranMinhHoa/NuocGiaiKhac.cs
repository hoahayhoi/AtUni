﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2001215784_TranMinhHoa
{
    class NuocGiaiKhac
    {
        string ten, dvt;

        int soLuong;
        float donGia;

        static float VAT = 10/100;


        public NuocGiaiKhac() { }

        public NuocGiaiKhac(string pten, string pdvt, int psoLuong, float pdonGia) 
        {
            this.ten = pten;
            this.dvt = pdvt;
            this.soLuong = psoLuong;
            this.donGia = pdonGia;
        }

        public void nhap()
        {
            Console.WriteLine("");
        }

        public float ThanhTien()
        {
            if (this.dvt == "ket" || this.dvt == "thung") 
            {
                return this.soLuong * this.donGia * 2 * VAT;
            }

            else if (this.dvt == "chai")
            {
                return (this.soLuong * this.donGia / 20) * 2 * VAT;
            }
            else return (this.soLuong * this.donGia / 24) * 2 * VAT;
        }


    }
}
