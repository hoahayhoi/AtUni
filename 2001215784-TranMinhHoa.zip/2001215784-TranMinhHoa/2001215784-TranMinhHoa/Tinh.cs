﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2001215784_TranMinhHoa
{
    class Tinh
    {
        double a, b;

        public Tinh() { }

        public Tinh(double pa, double pb)
        {
            this.a = pa;
            this.b = pb;
        }


        public double Tong()
        {
            return a + b;
        }

        public double Tong(double x, double y)
        {
            return x + y;
        }

        public double Hieu()
        {
            return a - b;
        }
        public double Hieu(double x, double y)
        {
            return x - y;
        }

        public double Tich()
        {
            return a * b;
        }
        public double Tich(double x, double y)
        {
            return x * y;
        }


        public double? Thuong()
        {
            if (a == 0) return null;
            return a / b;
        }
        public double? Thuong(double x, double y)
        {
            if (x == 0) return null;
            return x / y;
        }


    }
}
