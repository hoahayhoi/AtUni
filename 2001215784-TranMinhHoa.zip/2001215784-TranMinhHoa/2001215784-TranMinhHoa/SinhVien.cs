﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2001215784_TranMinhHoa
{
    class SinhVien
    {
        string maSV, hoTen;
        float dtb;


        public SinhVien() { }

        public SinhVien(string ma, string ten, float diem)
        {
            this.maSV = ma;
            this.hoTen = ten;
            this.dtb = diem;
        }


        public string XepLoai(){
            if(this.dtb > 10) return "loi!";
            else if (this.dtb >= 8.0) return "gioi";
            else if (this.dtb >= 6.5) return "kha";
            else if (this.dtb >= 5) return "trung binh";
            else if(this.dtb >= 0) return "yeu";
            else return "loi";
        }

        public void KetQua(string kq)
        {
            if (kq == "gioi") Console.WriteLine("Loai Gioi!");
            else if (kq == "kha") Console.WriteLine("Loai Kha!");
            else if (kq == "trung binh") Console.WriteLine("Loai Trung Binh!");
            else if(kq == "yeu") Console.WriteLine("Loai Yeu!");
            else Console.WriteLine("Loi khong the xep loai. Vui long nhap trong thang diem 10");
        }

        public void Xuat()
        {
            Console.WriteLine("Thong tin sinh vien: ");
            Console.WriteLine("Ma So: {0} ; Ho ten: {1} ; Diem Trung Binh: {2} .", this.maSV, this.hoTen, this.dtb);
        }


    }
}
