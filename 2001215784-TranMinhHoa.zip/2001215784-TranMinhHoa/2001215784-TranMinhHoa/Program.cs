﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2001215784_TranMinhHoa
{
    class Program
    {
        static void Main(string[] args)
        {
            //Tinh ab = new Tinh(2, 3);

            //double kq = 0;
            //kq = ab.Tong();

            //Console.WriteLine("Tong hai so a , b la: {0}", kq);

            //kq = ab.Hieu();
            //Console.WriteLine("Hieu hai so a, b la: {0}", kq);

            //kq = ab.Tich();
            //Console.WriteLine("Tich hai so a, b la: {0}", kq);

            //double? kq2;
            //if(kq2 == null) 
            //Console.WriteLine("Thuong hai so a, b la: {0}", kq);



            //SinhVien a = new SinhVien("SV001", "Tran Minh Hoa", (float)-50
            //a.Xuat();
            //a.KetQua(a.XepLoai());


            //PhuongTrinhBac1 ptb1 = new PhuongTrinhBac1(1, 3);

            //ptb1.Xuat();
            //ptb1.Giai();


            //PhuongTrinhBac2 ptb2 = new PhuongTrinhBac2(1, -4, 3);

            //ptb2.Xuat();


            //ptb2.Giai();











            Console.ReadKey();


        }
    }
}
