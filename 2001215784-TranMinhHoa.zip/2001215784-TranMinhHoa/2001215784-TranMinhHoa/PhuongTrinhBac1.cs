﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2001215784_TranMinhHoa
{
    class PhuongTrinhBac1
    {
        protected int a, b;

        public PhuongTrinhBac1() { }

        public PhuongTrinhBac1(int pa, int pb)
        {
            this.a = pa;
            this.b = pb;
        }

        public virtual void Xuat()
        {
            Console.WriteLine("{0} {1}", this.a, this.b);
        }

        public virtual void Giai()
        {
            if (this.a == 0)
                if (b == 0) Console.WriteLine("Phuong trinh co vo so nghiem!");
                else
                    Console.WriteLine("Phuong trinh vo nghiem");
            else
            {
                Console.WriteLine("Ket qua la: {0}", -this.b / this.a);
            }
        }

    }
}
