﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2001215784_TranMinhHoa
{
    class PhuongTrinhBac2:PhuongTrinhBac1
    {
        int c;

        public PhuongTrinhBac2() { }

        public PhuongTrinhBac2(int pc, int pa, int pb):base(pa, pb) 
        {
            this.c = pc;
        }

        public override void Xuat()
        {
            Console.WriteLine("He so a: {0}", this.c);
            Console.WriteLine("He so b va c: ");
            base.Xuat();
        }

        public override void Giai()
        {

            double delta = (double) (a * a) - (4 * c * b);
            if (delta < 0) Console.WriteLine("Phuong trinh vo nghiem!");
            else if (delta == 0) Console.WriteLine("Phuong trinh co nghiem kep la: {0}", ((double)-a / (2 * (double)c)));
            else
            {
                Console.WriteLine("Nghiem thu nhat la: {0}", (((double)-a + Math.Sqrt(delta)) / 2 * (double)c));
                Console.WriteLine("Nghiem thu hai la: {0}", (((double)-a - Math.Sqrt(delta)) / 2 * (double)c));
            }
        }

        
    }
}
